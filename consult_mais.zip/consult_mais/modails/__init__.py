# Package `modails` init
# Arquivo criado para tornar a pasta um pacote Python e permitir imports como
# `from modails.paciente import Paciente`.
